public class TrainingGround {
    public static void main(String[] args) {

    }
}
