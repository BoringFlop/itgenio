public interface Mortal {
     public boolean isAlive();

}
